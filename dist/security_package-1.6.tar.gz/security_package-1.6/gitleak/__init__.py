# gitleaks_installer/__init__.py
from .installer import install_gitleaks
